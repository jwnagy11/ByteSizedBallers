﻿namespace OfficeHourInterface.Pages.DataClasses
{
    public class Instructs
    {
        public int courseID { get; set; }
        public int instructorID { get; set; }
    }
}
