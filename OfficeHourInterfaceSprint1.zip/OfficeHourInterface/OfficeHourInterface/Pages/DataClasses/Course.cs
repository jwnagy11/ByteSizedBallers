﻿namespace OfficeHourInterface.Pages.DataClasses
{
    public class Course
    {
        public int courseID { get; set; }
        public String courseName { get; set; }
        public String courseInfo { get; set; }
        public int courseNumber { get; set; }
        public int courseSection { get; set; }
    }
}
