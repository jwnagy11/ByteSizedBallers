﻿namespace OfficeHourInterface.Pages.DataClasses
{
    public class Enrolls
    {
        public int courseID { get; set; }
        public int studentID { get; set; }
    }
}
