﻿namespace OfficeHourInterface.Pages.DataClasses
{

    // appropriate info for office hour 
    public class OfficeHour
    {
        public int officeHourID { get; set; }
        public String officeHourTime { get; set; }
        public int instructorID { get; set; }
        public int locationID { get; set; }
    }
}
