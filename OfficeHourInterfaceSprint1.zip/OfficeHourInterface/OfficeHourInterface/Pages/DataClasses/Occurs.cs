﻿namespace OfficeHourInterface.Pages.DataClasses
{
    public class Occurs
    {
        public int courseID { get; set; }   
        public int locationID { get; set; }


    }
}
