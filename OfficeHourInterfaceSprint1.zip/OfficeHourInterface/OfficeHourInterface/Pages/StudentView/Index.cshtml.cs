using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using OfficeHourInterface.Pages.DataClasses;
using OfficeHourInterface.Pages.DB;
using System.Data.SqlClient;
using System.Numerics;
using System.Reflection;

namespace OfficeHourInterface.Pages.StudentView
{
    public class StudentInterfaceModel : PageModel
    {
        [BindProperty]
        public Student curStudent { get; set; }
   

        public StudentInterfaceModel()
        {
            curStudent = new Student();
        }

   

        public IActionResult OnGet(int studentid)
        {

            // Validates that the current user is allowed on this page

            if (HttpContext.Session.GetString("username") == null || HttpContext.Session.Get("isInstructor").Equals("No"))
            {
                return RedirectToPage("../Index");
            } 
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetInt32("UserID") != studentid && HttpContext.Session.GetString("isInstructor").Equals("No"))
            {
                return RedirectToPage("Index", new { studentid = HttpContext.Session.GetInt32("UserID") });
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetString("isInstructor").Equals("Yes"))
            {
                return RedirectToPage("../Index");
            }


            // Gets the student information 

            SqlDataReader singleStudentReader = DBClass.SingleStudentReader(studentid);
            while (singleStudentReader.Read())
            {
                curStudent.studentID = studentid;
                curStudent.studentFirstName = singleStudentReader["studentFirstName"].ToString();
                curStudent.studentLastName = singleStudentReader["studentLastName"].ToString();
                curStudent.studentEmail = singleStudentReader["studentEmail"].ToString();
                curStudent.studentPhoneNumber = singleStudentReader["studentPhoneNumber"].ToString();
                curStudent.major = singleStudentReader["major"].ToString();
            }
            singleStudentReader.Close();
            DBClass.Lab1DBConnection.Close();

            return Page();

        }
    }
}
