using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeHourInterface.Pages.DataClasses;

namespace OfficeHourInterface.Pages.StudentView
{
    public class NotificationModel : PageModel
    {
        public IActionResult OnGet(int studentid)
        {


            // Validates that the user is allowed on this page

            if (HttpContext.Session.GetString("username") == null || HttpContext.Session.Get("isInstructor").Equals("No"))
            {
                return RedirectToPage("../Index");
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetInt32("UserID") != studentid && HttpContext.Session.GetString("isInstructor").Equals("No"))
            {
                return RedirectToPage("OfficeHourInfo", new { studentid = HttpContext.Session.GetInt32("UserID") });
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetString("isInstructor").Equals("Yes"))
            {
                return RedirectToPage("../Index");
            }

            return Page();
        }
    }
}
