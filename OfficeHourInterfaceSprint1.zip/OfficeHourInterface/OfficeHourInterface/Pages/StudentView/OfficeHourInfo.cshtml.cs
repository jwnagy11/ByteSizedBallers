using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using OfficeHourInterface.Pages.DataClasses;
using OfficeHourInterface.Pages.DB;
using System.Data.SqlClient;

namespace OfficeHourInterface.Pages.StudentView
{
    public class OfficeHourInfoModel : PageModel
    {

        [BindProperty]
        public List<int> queueOfficeId { get; set; }
        [BindProperty]
        public List<SelectListItem> instructorList { get; set; }
        [BindProperty]
        public int instructorID { get; set; }
        [BindProperty]
        public string instructorName { get; set; }
        [BindProperty]
        public List<int> instructorIds { get; set; }

        public  OfficeHourInfoModel() { 
            queueOfficeId = new List<int>();
            instructorList = new List<SelectListItem>();
            instructorIds = new List<int>();
        }
        public IActionResult OnGet(int studentid)
        {
            // Validates that the user is allowed on this page

            if (HttpContext.Session.GetString("username") == null || HttpContext.Session.Get("isInstructor").Equals("No"))
            {
                return RedirectToPage("../Index");
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetInt32("UserID") != studentid && HttpContext.Session.GetString("isInstructor").Equals("No"))
            {
                return RedirectToPage("OfficeHourInfo", new { studentid = HttpContext.Session.GetInt32("UserID") });
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetString("isInstructor").Equals("Yes"))
            {
                return RedirectToPage("../Index");
            }
            SqlDataReader instructorReader = DBClass.InstructorReader();

            // grabs a list of all the instructors

            while (instructorReader.Read())
            {
                instructorList.Add(
                    new SelectListItem(
                    instructorReader["instructorFirstName"].ToString() + " " + instructorReader["instructorLastName"].ToString(),
                     instructorReader["instructorID"].ToString()));

            }

            instructorReader.Close();
            DBClass.Lab1DBConnection.Close();

            return Page();

        }

        public void OnPost() {

            // Grabs a list of all the instructors

            SqlDataReader instructorReader = DBClass.InstructorReader();

            while (instructorReader.Read())
            {
                instructorList.Add(
                    new SelectListItem(
                    instructorReader["instructorFirstName"].ToString() + " " + instructorReader["instructorLastName"].ToString(),
                     instructorReader["instructorID"].ToString()));

            }

            instructorReader.Close();
            DBClass.Lab1DBConnection.Close();

        }

        public IActionResult OnPostSearch() {
           SqlDataReader instructorReader = DBClass.GeneralReaderQuery("SELECT * FROM Instructor WHERE UPPER(Concat(Instructor.instructorFirstName, Instructor.instructorLastName)) Like ' %" + instructorName +"%'");

            while (instructorReader.Read())
            {
                instructorIds.Add(Int32.Parse(instructorReader["instructorID"].ToString()));
            }
            instructorReader.Close();
            DBClass.Lab1DBConnection.Close();
            return Page();
        }
    }
}
