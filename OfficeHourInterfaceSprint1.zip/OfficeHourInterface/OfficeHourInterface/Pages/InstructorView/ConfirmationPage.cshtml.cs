using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeHourInterface.Pages.DataClasses;
using OfficeHourInterface.Pages.DB;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace OfficeHourInterface.Pages.InstructorView
{
    public class ConfirmationPageModel : PageModel
    {

        public Instructor curInstructor { get; set; }

        public ConfirmationPageModel()
        {
            curInstructor = new Instructor();
        }

        public IActionResult OnGet(int instructorid, int studentid, int officeHourid)

        {
            // Validates that the user is allowed on this page

            if (HttpContext.Session.GetString("username") == null || HttpContext.Session.Get("isInstructor").Equals("Yes"))
            {
                return RedirectToPage("../Index");
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetInt32("UserID") != instructorid && HttpContext.Session.GetString("isInstructor").Equals("No"))
            {
                return RedirectToPage("Index", new { instructorid = HttpContext.Session.GetInt32("UserID") });
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetString("isInstructor").Equals("No"))
            {
                return RedirectToPage("../Index");
            }

            // This will send a notification to the students inbox
            SqlDataReader tempReader = DBClass.SingleInstructorReader(Int32.Parse(HttpContext.Session.GetInt32("UserID").ToString()));

            while (tempReader.Read())
            {
                curInstructor.instructorFirstName = tempReader["instructorFirstName"].ToString();
                curInstructor.instructorLastName = tempReader["instructorLastName"].ToString();
            }

            tempReader.Close();
            DBClass.Lab1DBConnection.Close();

            tempReader = DBClass.GeneralReaderQuery(" SELECT Location.buildingName, Location.roomNumber " +
                "FROM OfficeHour INNER JOIN Location ON OfficeHour.locationID = Location.locationID WHERE OfficeHour.officeHourID =" + officeHourid);
            string message = "";
            while (tempReader.Read())
            {
                message = curInstructor.instructorFirstName + " " + curInstructor.instructorLastName + " is ready to see you at " + tempReader["buildingName"].ToString() + " " + tempReader["roomNumber"].ToString() + ".";
            }

            tempReader.Close();
            DBClass.Lab1DBConnection.Close();


            DBClass.GeneralReaderQuery("INSERT INTO Notification VALUES('" + message + "', " + studentid + ", " + HttpContext.Session.GetInt32("UserID").ToString() + ")");
            DBClass.Lab1DBConnection.Close();

      
            SqlDataReader stuEmail = DBClass.GeneralReaderQuery("SELECT studentEmail FROM Student WHERE studentID = " + studentid);
            string email = "";
            while(stuEmail.Read()) {
                email = stuEmail["studentEmail"].ToString();
            }
            stuEmail.Close();
            DBClass.Lab1DBConnection.Close();
            DBClass.SendEmail(email, message);
            DBClass.Lab1DBConnection.Close();
            return Page();
        }

    }
}
