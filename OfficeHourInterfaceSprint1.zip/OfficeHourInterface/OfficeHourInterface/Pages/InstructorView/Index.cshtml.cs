using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using OfficeHourInterface.Pages.DataClasses;
using OfficeHourInterface.Pages.DB;
using System.Collections.Concurrent;
using System.Data.SqlClient;
using System.Numerics;

namespace OfficeHourInterface.Pages.InstructorView
{
    public class InstructorInterfaceModel : PageModel
    {
        [BindProperty]
        public Instructor currentInstructor { get; set; }
        [BindProperty]
        public List<SelectListItem> officeHours { get; set; }
        [BindProperty]
        public int officeHourID { get; set; }
        [BindProperty]
        public int instructorID { get; set; }

        public InstructorInterfaceModel()
        {
            currentInstructor = new Instructor();
            officeHours = new List<SelectListItem>();
           
        }
        public IActionResult OnGet(int instructorid)
        {

            // Validates that the user is allowed on this page

            if (HttpContext.Session.GetString("username") == null || HttpContext.Session.Get("isInstructor").Equals("Yes"))
            {
                return RedirectToPage("../Index");
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetInt32("UserID") != instructorid && HttpContext.Session.GetString("isInstructor").Equals("No"))
            {
                return RedirectToPage("Index", new { instructorid = HttpContext.Session.GetInt32("UserID") });
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetString("isInstructor").Equals("No"))
            {
                return RedirectToPage("../Index");
            }
            //reads in a single instructor

            SqlDataReader singleInstructorReader = DBClass.SingleInstructorReader(instructorid);
            while (singleInstructorReader.Read())
            {
                currentInstructor = (new Instructor
                {
                    instructorID = Int32.Parse(singleInstructorReader["instructorID"].ToString()),
                    instructorFirstName = singleInstructorReader["instructorFirstName"].ToString(),
                    instructorLastName = singleInstructorReader["instructorLastName"].ToString(),
                    instructorEmail = singleInstructorReader["instructorEmail"].ToString(),
                });
            }

            singleInstructorReader.Close();
            DBClass.Lab1DBConnection.Close();

            // reads in a professor office hours

            SqlDataReader officeHourReader = DBClass.OfficeHourReader(instructorid);
            while (officeHourReader.Read())
            {
                officeHours.Add(new SelectListItem(

                    officeHourReader["officeHourTime"].ToString(),
                    officeHourReader["officeHourID"].ToString()));
            }

            singleInstructorReader.Close();
            DBClass.Lab1DBConnection.Close();

            // reads in all the professors meetins 

            

            return Page();

        }

        public void OnPost()
        {



            // reads in a professor office hours

            SqlDataReader officeHourReader = DBClass.OfficeHourReader(instructorID);
        
            while (officeHourReader.Read())
            {
                officeHours.Add(new SelectListItem(

                    officeHourReader["officeHourTime"].ToString(),
                    officeHourReader["officeHourID"].ToString()));
            }
            officeHourReader.Close();
            DBClass.Lab1DBConnection.Close();
        }


    }
}
