using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeHourInterface.Pages.DB;
using System.ComponentModel.DataAnnotations;

namespace OfficeHourInterface.Pages
{
    public class CreateAccountInstructorModel : PageModel
    {

        [BindProperty]
        [Required]
        public String firstName { get; set; }

        [BindProperty]
        [Required]
        public String lastName { get; set; }


        [BindProperty]
        [Required]
        public String email { get; set; }


        [BindProperty]
        [Required]
        public String Username { get; set; }

        [BindProperty]
        [Required]
        public String Password { get; set; }
        public int NumInstructors { get; set; }
        public int NumCredentials { get; set; }

        // gets the count for the instructor to add it to the hashedcredentials table
        public void OnGet()
        {

       
            NumInstructors = DBClass.LoginQuery("SELECT COUNT(instructorID) FROM Instructor");
            DBClass.Lab1DBConnection.Close();
            NumCredentials = DBClass.LoginQuery2("SELECT COUNT(credentialsID) FROM HashedCredentials");
            DBClass.Lab1DBConnection.Close();
        }

        // adds the new instructor
        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                NumInstructors = DBClass.LoginQuery("SELECT COUNT(instructorID) FROM Instructor");
                DBClass.Lab1DBConnection.Close();
                DBClass.GeneralReaderQuery("INSERT INTO Instructor Values('" + firstName + "', '" + lastName + "', '" + email +"')");
                DBClass.Lab1DBConnection.Close();
                DBClass.CreateHashedUserInstructor(Username, Password, NumInstructors + 1, "Yes");
                DBClass.Lab1DBConnection.Close();
                return RedirectToPage("Index");
            }
                
            return Page();
        }

        public IActionResult OnPostCancel()
        {
            return RedirectToPage("Index");
        }

        public IActionResult OnPostPopulateHandler()
        {
            ModelState.Clear();
    
            firstName = "Jeremy";
            lastName = "Ezell";
            email = "ezelljd@jmu.edu";
            Username = "ezelljd";
            Password = "54321";

            return Page();
        }
        public IActionResult OnPostClearHandler()
        {
            ModelState.Clear();
     
            firstName = "";
            lastName = "";
            email = "";
            Username = "";
            Password = "";

            return Page();
        }
    }
}
