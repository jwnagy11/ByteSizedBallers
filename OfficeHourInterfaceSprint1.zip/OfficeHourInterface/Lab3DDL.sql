
DROP TABLE Notification;
DROP TABLE Occurs;
DROP TABLE Instructs;
DROP TABLE Enrolls;
DROP TABLE Queue;
DROP TABLE Meeting; 
DROP TABLE OfficeHour;
DROP TABLE Course;
DROP TABLE Student;
DROP TABLE Instructor;
DROP TABLE Location;


CREATE TABLE Location (
  locationID       INTEGER NOT NULL PRIMARY KEY,
  buildingName     VARCHAR(30),
  roomNumber       INTEGER,
);

CREATE TABLE Instructor (
  instructorID        	INTEGER NOT NULL IDENTITY PRIMARY KEY,
  instructorFirstName 	VARCHAR(20) NOT NULL,
  instructorLastName    VARCHAR(20) NOT NULL,
  instructorEmail     	VARCHAR(30) NOT NULL
);

CREATE TABLE Student (
  studentID   		   INTEGER NOT NULL IDENTITY PRIMARY KEY,
  studentFirstName 	   VARCHAR(20) NOT NULL,
  studentLastName      VARCHAR(20) NOT NULL,
  studentEmail  	   VARCHAR(30) NOT NULL,
  studentPhoneNumber   VARCHAR(30) NOT NULL,
  major				   VARCHAR(20) NOT NULL
);

CREATE TABLE Course (
  courseID  		INTEGER NOT NULL PRIMARY KEY,
  courseName	    VARCHAR(50) NOT NULL,
  courseInfo		VARCHAR(50) NOT NULL,
  courseNumber		INTEGER NOT NULL, 
  courseSection		INTEGER NOT NULL
);

CREATE TABLE OfficeHour (
  officeHourID  		INTEGER NOT NULL PRIMARY KEY,
  officeHourTime     	VARCHAR(10),
  instructorID   		INTEGER NOT NULL REFERENCES Instructor(instructorID),
  locationID   		    INTEGER NOT NULL REFERENCES Location(locationID)
);

CREATE TABLE Meeting (
  meetingID  		INTEGER NOT NULL IDENTITY PRIMARY KEY,
  meetingPurpose    VARCHAR(30),
  meetingDate		VARCHAR(30) NOT NULL,
  meetingTime		VARCHAR(15),
  studentID   		INTEGER NOT NULL,
  partnerID   		INTEGER,
  instructorID      INTEGER NOT NULL,  
  locationID   		INTEGER NOT NULL,
  FOREIGN KEY (studentID) 	    REFERENCES Student(studentID),
  FOREIGN KEY (partnerID) 	    REFERENCES Student(studentID),
  FOREIGN KEY (instructorID)    REFERENCES Instructor(instructorID),
  FOREIGN KEY (locationID) 	    REFERENCES Location(locationID)
);


CREATE TABLE Queue (
  officeHourID  	   INTEGER NOT NULL REFERENCES OfficeHour(officeHourID),
  studentID     	   INTEGER NOT NULL REFERENCES Student(studentID),
  locationID 		   INTEGER NOT NULL,
  placeInQueue		   INTEGER NOT NULL,
  FOREIGN KEY (locationID) 	  REFERENCES Location(locationID),
  PRIMARY KEY (officeHourID, studentID)
);

CREATE TABLE Notification (
  notificationID  	   INTEGER NOT NULL IDENTITY PRIMARY KEY,
  message			   VARCHAR(100),
  studentID  	       INTEGER NOT NULL REFERENCES Student(studentID),
  instructorID     	   INTEGER NOT NULL REFERENCES instructor(instructorID)
);


CREATE TABLE Enrolls (
  courseId  	       INTEGER NOT NULL REFERENCES Course(courseID),
  studentID     	   INTEGER NOT NULL REFERENCES Student(studentID),
  PRIMARY KEY (courseID, studentID)
);

CREATE TABLE Instructs (
  courseId  	       INTEGER NOT NULL REFERENCES Course(courseID),
  instructorID     	   INTEGER NOT NULL REFERENCES Instructor(instructorID),
  PRIMARY KEY (courseID, instructorID)
);

CREATE TABLE Occurs (
  courseId  	       INTEGER NOT NULL REFERENCES Course(courseID),
  locationID     	   INTEGER NOT NULL REFERENCES Location(locationID),
  PRIMARY KEY (courseID, locationID)
);



-- Location Table Values
INSERT INTO Location VALUES (1, 'Hartman', 2030);
INSERT INTO Location VALUES (2, 'Showker', 5021);
INSERT INTO Location VALUES (3, 'Hartman', 2032);
INSERT INTO Location VALUES (4, 'Hartman', 2040);
INSERT INTO Location VALUES (5, 'Hartman', 2043);
INSERT INTO Location VALUES (6, 'Showker', 5010);
INSERT INTO Location VALUES (7, 'Showker', 5004);
INSERT INTO Location VALUES (8, 'Hartman', 2029);
INSERT INTO Location VALUES (9, 'Showker', 5003);
INSERT INTO Location VALUES (10, 'Hartman', 3030);

-- Instructor Table VALUES
INSERT INTO Instructor VALUES ('Jeremy', 'Ezell', 'jezell@dukes.jmu.edu');
INSERT INTO Instructor VALUES ('Jeff', 'May', 'jmay@dukes.jmu.edu');
INSERT INTO Instructor VALUES ('Michel', 'Mitri', 'mmitri@dukes.jmu.edu');
INSERT INTO Instructor VALUES ('Carey', 'Cole', 'ccole@dukes.jmu.edu');
INSERT INTO Instructor VALUES ('Jim', 'Jewitt', 'jjewitt@dukes.jmu.edu');
INSERT INTO Instructor VALUES ('admin', 'instructor', 'iadmin@dukes.jmu.edu');

-- Course Table Values 
INSERT INTO Course VALUES (1, 'Enterprise Architecture', 'Entry Level CIS Class', 304, 1);
INSERT INTO Course VALUES (2, 'Telecommunications', 'introduction to telecommunication', 320, 1);
INSERT INTO Course VALUES (3, 'Database Design', 'Learn SQL and ERD modeling', 330, 1);
INSERT INTO Course VALUES (4, 'Intermediate Programming', 'Learn Object Oriented Programming in Java', 331, 1);
INSERT INTO Course VALUES (5, 'IS Development and Implementation', 'CIS Capstone', 484, 1);
INSERT INTO Course VALUES (6, 'Enterprise Architecture', 'Entry Level CIS Class', 304, 2);
INSERT INTO Course VALUES (7, 'Telecommunications', 'introduction to telecommunication', 320, 2);
INSERT INTO Course VALUES (8, 'Database Design', 'Learn SQL and ERD modeling', 330, 2);
INSERT INTO Course VALUES (9, 'Intermediate Programming', 'Learn Object Oriented Programming in Java', 331, 2);
INSERT INTO Course VALUES (10, 'IS Development and Implementation', 'CIS Capstone', 484, 2);

-- Student Table Values 
INSERT INTO Student VALUES ('Nicholas', 'Broger', 'brogernh@dukes.jmu.edu', 5405555555, 'CIS');
INSERT INTO Student VALUES ('Joseph', 'Nagy', 'nagyj@dukes.jmu.edu', 5405558989, 'CIS');
INSERT INTO Student VALUES ('Aaron', 'Scott', 'scotta@dukes.jmu.edu', 5406782389, 'CIS');
INSERT INTO Student VALUES ('John', 'Smith', 'smithj@dukes.jmu.edu', 5404537372, 'CIS');
INSERT INTO Student VALUES ('William', 'Aarons', 'aaronsw@dukes.jmu.edu', 5406788234, 'CIS');
INSERT INTO Student VALUES ('Trevor', 'Riley', 'rileyt@dukes.jmu.edu', 5403231673, 'CIS');
INSERT INTO Student VALUES ('Luanne', 'Martin', 'martinl@dukes.jmu.edu', 5716783289, 'CIS');
INSERT INTO Student VALUES ('Chuck', 'Rizzo', 'rizzoc@dukes.jmu.edu', 5553920972, 'CIS');
INSERT INTO Student VALUES ('Aidan', 'Smith', 'smitha@dukes.jmu.edu', 5893420972, 'CIS');
INSERT INTO Student VALUES ('Emma', 'Stone', 'stonee@dukes.jmu.edu', 6073627972, 'CIS');
INSERT INTO Student VALUES ('Bill', 'Gates', 'gatesb@dukes.jmu.edu', 5678923096, 'CIS');
INSERT INTO Student VALUES ('Lauren', 'Rinker', 'rinkerl@dukes.jmu.edu', 5453827902, 'CIS');
INSERT INTO Student VALUES ('George', 'Soros', 'sorosg@dukes.jmu.edu', 6663337823, 'CIS');
INSERT INTO Student VALUES ('Connor', 'James', 'jamesc@dukes.jmu.edu', 7038927972, 'CIS');
INSERT INTO Student VALUES ('Anthony', 'Walters', 'waltersa@dukes.jmu.edu', 5557827302, 'CIS');
INSERT INTO Student VALUES ('Haley', 'Tabor', 'taborh@dukes.jmu.edu', 5783097312, 'CIS');
INSERT INTO Student VALUES ('Grant', 'Bloom', 'bloomg@dukes.jmu.edu', 5362120379, 'CIS');
INSERT INTO Student VALUES ('Audrey', 'MacDonald', 'macdonalda@dukes.jmu.edu', 5493227612, 'CIS');
INSERT INTO Student VALUES ('Michelle', 'Soros', 'sorosm@dukes.jmu.edu', 5489227314, 'CIS');
INSERT INTO Student VALUES ('Peter', 'Parker', 'parkerp@dukes.jmu.edu', 5409012372, 'CIS');

-- OfficeHour Table VALUES
INSERT INTO OfficeHour VALUES (1, '9:30-11:00', 1, 1);
INSERT INTO OfficeHour VALUES (2, '9:30-11:00', 2, 3);
INSERT INTO OfficeHour VALUES (3, '9:30-11:00', 3, 2);
INSERT INTO OfficeHour VALUES (4, '9:30-11:00', 5, 10);
INSERT INTO OfficeHour VALUES (5, '9:30-11:00', 4, 7);
INSERT INTO OfficeHour VALUES (6, '12:00-2:00', 1, 5);
INSERT INTO OfficeHour VALUES (7, '12:00-2:00', 2, 8);
INSERT INTO OfficeHour VALUES (8, '12:00-2:00', 3, 4);
INSERT INTO OfficeHour VALUES (9, '12:00-2:00', 4, 6);
INSERT INTO OfficeHour VALUES (10, '12:00-2:00', 5, 9);
INSERT INTO OfficeHour VALUES (11, '5:00-6:30', 1, 10);
INSERT INTO OfficeHour VALUES (12, '5:00-6:30', 2, 5);
INSERT INTO OfficeHour VALUES (13, '5:00-6:30', 3, 3);
INSERT INTO OfficeHour VALUES (14, '5:00-6:30', 4, 1);
INSERT INTO OfficeHour VALUES (15, '5:00-6:30', 5, 6);


-- Occurs Table Values 
INSERT INTO Occurs VALUES (1, 1);
INSERT INTO Occurs VALUES (2, 3);
INSERT INTO Occurs VALUES (3, 8);
INSERT INTO Occurs VALUES (4, 2);
INSERT INTO Occurs VALUES (5, 5);
INSERT INTO Occurs VALUES (6, 1);
INSERT INTO Occurs VALUES (7, 8);
INSERT INTO Occurs VALUES (8, 9);
INSERT INTO Occurs VALUES (9, 10);
INSERT INTO Occurs VALUES (10, 1);

-- Instructs Table Values
INSERT INTO Instructs VALUES (5, 1);
INSERT INTO Instructs VALUES (10, 1);
INSERT INTO Instructs VALUES (3, 2);
INSERT INTO Instructs VALUES (8, 2);
INSERT INTO Instructs VALUES (4, 3);
INSERT INTO Instructs VALUES (9, 3);
INSERT INTO Instructs VALUES (6, 4);
INSERT INTO Instructs VALUES (7, 4);
INSERT INTO Instructs VALUES (2, 5);
INSERT INTO Instructs VALUES (1, 5);

-- Meeting Table Values
INSERT INTO Meeting VALUES ('Lab 1 Part 1', '01-25-2023', '8:00-8:30', 1, NULL, 1, 6);
INSERT INTO Meeting VALUES ('Lab 1 Part 2', '02-03-2023', '9:00-9:30', 1, 2, 1, 6);
INSERT INTO Meeting VALUES ('PA1', '01-30-2023', '5:00-5:30', 20, NULL, 3, 2);
INSERT INTO Meeting VALUES ('Lab 1 Part 3', '02-08-2023', '9:00-9:30', 1, 2, 1, 6);
INSERT INTO Meeting VALUES ('HW3', '01-25-2023', '6:00-6:30', 17, NULL, 4, 2);
INSERT INTO Meeting VALUES ('ERD 1', '01-28-2023', '11:15-11:30', 5, 20, 2, 9);
INSERT INTO Meeting VALUES ('HW2', '02-07-2023', '8:00-8:30', 9, NULL, 5, 4);
INSERT INTO Meeting VALUES ('PA1', '02-01-2023', '7:15-7:30', 13, NULL, 3, 7);

--Enrolls Table Values
INSERT INTO Enrolls VALUES (1, 1);
INSERT INTO Enrolls VALUES (2, 1);
INSERT INTO Enrolls VALUES (3, 1);
INSERT INTO Enrolls VALUES (4, 1);
INSERT INTO Enrolls VALUES (5, 1);
INSERT INTO Enrolls VALUES (6, 2);
INSERT INTO Enrolls VALUES (7, 2);
INSERT INTO Enrolls VALUES (8, 2);
INSERT INTO Enrolls VALUES (9, 2);
INSERT INTO Enrolls VALUES (10, 2);
INSERT INTO Enrolls VALUES (1, 3);
INSERT INTO Enrolls VALUES (2, 3);
INSERT INTO Enrolls VALUES (3, 3);
INSERT INTO Enrolls VALUES (4, 3);
INSERT INTO Enrolls VALUES (5, 3);
INSERT INTO Enrolls VALUES (6, 4);
INSERT INTO Enrolls VALUES (7, 4);
INSERT INTO Enrolls VALUES (8, 4);
INSERT INTO Enrolls VALUES (9, 4);
INSERT INTO Enrolls VALUES (10, 4);
INSERT INTO Enrolls VALUES (6, 5);
INSERT INTO Enrolls VALUES (7, 5);
INSERT INTO Enrolls VALUES (8, 5);
INSERT INTO Enrolls VALUES (9, 5);
INSERT INTO Enrolls VALUES (10, 5);
INSERT INTO Enrolls VALUES (1, 6);
INSERT INTO Enrolls VALUES (2, 6);
INSERT INTO Enrolls VALUES (3, 6);
INSERT INTO Enrolls VALUES (4, 6);
INSERT INTO Enrolls VALUES (5, 6);
INSERT INTO Enrolls VALUES (6, 7);
INSERT INTO Enrolls VALUES (7, 7);
INSERT INTO Enrolls VALUES (8, 7);
INSERT INTO Enrolls VALUES (9, 7);
INSERT INTO Enrolls VALUES (10, 7);
INSERT INTO Enrolls VALUES (1, 8);
INSERT INTO Enrolls VALUES (2, 8);
INSERT INTO Enrolls VALUES (3, 8);
INSERT INTO Enrolls VALUES (4, 8);
INSERT INTO Enrolls VALUES (5, 8);
INSERT INTO Enrolls VALUES (6, 9);
INSERT INTO Enrolls VALUES (7, 9);
INSERT INTO Enrolls VALUES (8, 9);
INSERT INTO Enrolls VALUES (9, 9);
INSERT INTO Enrolls VALUES (10, 9);
INSERT INTO Enrolls VALUES (6, 10);
INSERT INTO Enrolls VALUES (7, 10);
INSERT INTO Enrolls VALUES (8, 10);
INSERT INTO Enrolls VALUES (9, 10);
INSERT INTO Enrolls VALUES (10, 10);
INSERT INTO Enrolls VALUES (1, 11);
INSERT INTO Enrolls VALUES (2, 11);
INSERT INTO Enrolls VALUES (3, 11);
INSERT INTO Enrolls VALUES (4, 11);
INSERT INTO Enrolls VALUES (5, 11);
INSERT INTO Enrolls VALUES (1, 12);
INSERT INTO Enrolls VALUES (2, 12);
INSERT INTO Enrolls VALUES (3, 12);
INSERT INTO Enrolls VALUES (4, 12);
INSERT INTO Enrolls VALUES (5, 12);
INSERT INTO Enrolls VALUES (6, 13);
INSERT INTO Enrolls VALUES (7, 13);
INSERT INTO Enrolls VALUES (8, 13);
INSERT INTO Enrolls VALUES (9, 13);
INSERT INTO Enrolls VALUES (10, 13);
INSERT INTO Enrolls VALUES (1, 14);
INSERT INTO Enrolls VALUES (2, 14);
INSERT INTO Enrolls VALUES (3, 14);
INSERT INTO Enrolls VALUES (4, 14);
INSERT INTO Enrolls VALUES (5, 14);
INSERT INTO Enrolls VALUES (6, 15);
INSERT INTO Enrolls VALUES (7, 15);
INSERT INTO Enrolls VALUES (8, 15);
INSERT INTO Enrolls VALUES (9, 15);
INSERT INTO Enrolls VALUES (10, 15);
INSERT INTO Enrolls VALUES (1, 16);
INSERT INTO Enrolls VALUES (2, 16);
INSERT INTO Enrolls VALUES (3, 16);
INSERT INTO Enrolls VALUES (4, 16);
INSERT INTO Enrolls VALUES (5, 16);
INSERT INTO Enrolls VALUES (6, 17);
INSERT INTO Enrolls VALUES (7, 17);
INSERT INTO Enrolls VALUES (8, 17);
INSERT INTO Enrolls VALUES (9, 17);
INSERT INTO Enrolls VALUES (10, 17);
INSERT INTO Enrolls VALUES (1, 18);
INSERT INTO Enrolls VALUES (2, 18);
INSERT INTO Enrolls VALUES (3, 18);
INSERT INTO Enrolls VALUES (4, 18);
INSERT INTO Enrolls VALUES (5, 18);
INSERT INTO Enrolls VALUES (6, 19);
INSERT INTO Enrolls VALUES (7, 19);
INSERT INTO Enrolls VALUES (8, 19);
INSERT INTO Enrolls VALUES (9, 19);
INSERT INTO Enrolls VALUES (10, 19);
INSERT INTO Enrolls VALUES (1, 20);
INSERT INTO Enrolls VALUES (2, 20);
INSERT INTO Enrolls VALUES (3, 20);
INSERT INTO Enrolls VALUES (4, 20);
INSERT INTO Enrolls VALUES (5, 20);

-- Queue Table Values
INSERT INTO Queue VALUES (1, 1, 5, 1);
INSERT INTO Queue VALUES (2, 1, 8, 1);
INSERT INTO Queue VALUES (1, 2, 5, 2);
INSERT INTO Queue VALUES (2, 3, 8, 2);
INSERT INTO Queue VALUES (2, 4, 8, 3);
INSERT INTO Queue VALUES (3, 5, 4, 1);
INSERT INTO Queue VALUES (3, 6, 4, 2);
INSERT INTO Queue VALUES (4, 7, 6, 1);
INSERT INTO Queue VALUES (4, 8, 6, 2);
INSERT INTO Queue VALUES (5, 9, 9, 1);
INSERT INTO Queue VALUES (5, 10, 9, 2);
INSERT INTO Queue VALUES (6, 11, 10, 1);
INSERT INTO Queue VALUES (6, 12, 10, 2);
INSERT INTO Queue VALUES (7, 13, 2, 1);
INSERT INTO Queue VALUES (7, 14, 2, 2);
INSERT INTO Queue VALUES (8, 15, 3, 1);
INSERT INTO Queue VALUES (8, 16, 3, 2);
INSERT INTO Queue VALUES (9, 17, 7, 1);
INSERT INTO Queue VALUES (9, 18, 7, 2);
INSERT INTO Queue VALUES (10, 19, 1, 1);
INSERT INTO Queue VALUES (11, 14, 1, 1);
INSERT INTO Queue VALUES (12, 3, 5, 1);
INSERT INTO Queue VALUES (13, 7, 3, 1);
INSERT INTO Queue VALUES (14, 1, 2, 1);
INSERT INTO Queue VALUES (15, 6, 6, 1);
