
DROP Table HashedCredentials

CREATE TABLE HashedCredentials (
  credentialsID  		INTEGER NOT NULL IDENTITY PRIMARY KEY,
  username			VARCHAR(30),
  password			VARCHAR(100),
  studentID     	   INTEGER,
  instructorID     	   INTEGER,
  isInstructor      VARCHAR(30),
);



---- HashedCredentials Table Values --

INSERT INTO HashedCredentials VALUES ('jezell', '1000:++ToGGzMUL9oL2nLzWIYYbal3ORs/cxG:DbUfKe06lxykW5CM+uoIO2wAMUI=', NULL, 1, 'Yes');
INSERT INTO HashedCredentials VALUES ('jmay', '1000:96FhPqU+8uSYJZ7HjJM1Rthgw+7LO8dc:ifNYFdHUZMBrV7n4J+rCrByuiH8=', NULL, 2, 'Yes');
INSERT INTO HashedCredentials VALUES ('mmitri', '1000:q+g7MgBs09WesgyFvqxR5VuGTjsba4yO:u4nhRWOd144T5A+DFNXgk4RqGeU=', NULL, 3, 'Yes');
INSERT INTO HashedCredentials VALUES ('ccole', '1000:0KxlUZUSL4UYLHgwFYfh8LQWuNMXwOXn:XOFUPHUfuZecsnslAEVlqu8uXV8=', NULL, 4, 'Yes');
INSERT INTO HashedCredentials VALUES ('jjewitt', '1000:OxAO1Hh76yM08gcWKOiuNATJ/4LP9V9u:x/YrQhFYLtowhP55NFxCnSBXm0o=', NULL, 5, 'Yes');
--Admin Credentials
INSERT INTO HashedCredentials VALUES ('admin', '1000:yU9cwrtwcPu3hJfRkvLwNcif4uNED5u6:A/HhnUIf0ykbYhc7myRb4yCN4ok=', null, 6, 'Yes');

INSERT INTO HashedCredentials VALUES ('nbroger', '1000:Y4YEnDr79pZpgQk/syu7CNeXrJz8byV+:0CCxatMXN0rQMVFrDVCqE30lwEE=', 1, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('jnagy', '1000:hfoEP00M0nQd0e35rPKfblLhyhXlq1kD:9hfFpsgVipaXQqbwgZETXkoM+MI=', 2, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('ascott', '1000:nkkHnVMg9+Y4JV890T0UhIlxrtVmEOG9:FyrFPvdEEcLvArgS8ai37rdc6f8=', 3, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('jsmith', '1000:bQY9mZwDsCeAncRN9QGqafZUeLUz6Pc0:XWcjpcjlb9qiNU0jCLWvYziHV6k=', 4, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('waarons', '1000:TXTsM3Xhva/PcfG9gty/7zC4Z8UYEybJ:FpA6vPDJjD1+1oXxj20CoYsxJ+k=', 5, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('triley', '1000:mjbVl15NHfpVYoKS9ga2Nk1WliJdzatU:F49JQoZsEbCnfKPf2IGEmlZb5zY=', 6, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('lmartin', '1000:htBwv+CoqAXCgOIvIEhzc2IZGEXbMh0W:zwS4W0d0MI0RsMDyhDc3lYcMPec=', 7, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('crizzo', '1000:zb2AsylRyBWjWP0GQLsQmz5KJZOhSk1T:QWIt9kWukhTOFU76f6epDe4uiNI=', 8, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('asmith', '1000:5NoZyNDvEQlYCH8zATyoTV1Q/gXzWMB5:oF7+oDRx/nzRkeu1HabgKr4HStc=', 9, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('estone', '1000:T6z3g9RmOY+2Ct+xuoryJ6cUJJL0F2Wm:U2M7krQFHvYxLfNSwfxcCc+0YgQ=', 10, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('bgates', '1000:UXtpsbXhKvN31dk7Ne6gEaWR2oc3u2k4:hnWL3k9ra3ed/w38gX3z1GIIzlw=', 11, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('lrinker', '1000:5GdXB3L9HSg40nwBlqcQgCTbAzaW9202:NRmcWqcNQGu1egWmTyhh8J0HRC8=', 12, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('gsoros', '1000:5+/tbU0iytUuNChV4XsdEb5/xcTsfpuA:h20q+IcnAPAimdRsxURnUoV/rOA=', 13, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('cjames', '1000:WY7gNUODSruZRlwv95tsFppA4oTtvJGn:j85DBjR5MFp8JkPOUcyndVgqFUw=', 14, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('awalters', '1000:tAWcNUGLMgojOjvFd9JXnvfKIZVsed+i:Ls2RwT4C8od4pnIeszxO0nHWMCc=', 15, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('htabor', '1000:zET/vIP6r1XgkeIduyy1hMAYfxnDuUTp:DDc/bH+j6bLWuNjiSsJwuCzmXvU=', 16, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('gbloom', '1000:dexNeczFbCCuLHY2d06b4MzCEuPmbF6O:MTqk5sji8savUJBI6WaJDkioweU=', 17, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('amacdonald', '1000:YJecmqIljmLdB2T5ZFg7pKGSIjXDKu0n:HRoIiUuOpUtob9r/pKs2kznNp1U=', 18, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('msoros', '1000:XFMzEj8xfYWqfVujyhV2WED/fQMPyk95:RdelaI4/dMavo7IwVQRyIOdwqas=', 19, NULL, 'No');
INSERT INTO HashedCredentials VALUES ('pparker', '1000:Hmtwh7B5794hF1h4jZ0Qnh4XItjBG6eK:czhoxlcBB4KwoewQ8VWiRb97S8g=', 20, NULL, 'No');

