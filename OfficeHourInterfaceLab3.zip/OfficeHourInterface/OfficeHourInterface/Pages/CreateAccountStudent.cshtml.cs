using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeHourInterface.Pages.DataClasses;
using OfficeHourInterface.Pages.DB;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OfficeHourInterface.Pages
{
    public class CreateAccountModel : PageModel
    {
        [BindProperty]
        [Required]
        public String firstName { get; set; }

        [BindProperty]
        [Required]
        public String lastName { get; set; }

        [BindProperty]
        [Required]
        public String phoneNumber { get; set; }
        [BindProperty]
        public String email { get; set; }
        [BindProperty]
        public String major { get; set; }

        [BindProperty]
        [Required]
        public String Username { get; set; }

        [BindProperty]
        [Required]
        public String Password { get; set; }

        [BindProperty]
        public int NumStudents { get; set; }
        public int NumInstructors { get; set; }
        public int NumCredentials { get; set; }

        public void OnGet()
        {
          
        }


        // adds the new student to the database
        public IActionResult OnPost()
        {
            if(ModelState.IsValid)
            {
                NumStudents = DBClass.LoginQuery("SELECT COUNT(studentID) FROM Student");
                DBClass.Lab1DBConnection.Close();
                DBClass.GeneralReaderQuery("INSERT INTO Student Values('" + firstName + "', '" + lastName + "', '" + email + "', '" + phoneNumber + "', '" + major + "')");
                DBClass.Lab1DBConnection.Close();
                DBClass.CreateHashedUser(Username, Password, NumStudents + 1, "No");
                DBClass.Lab1DBConnection.Close();
                return RedirectToPage("Index");
            }
            return Page();
        }

        public IActionResult OnPostCancel()
        {
            return RedirectToPage("Index");
        }

        public IActionResult OnPostPopulate()
        {
            ModelState.Clear();
   
            firstName = "Nick";
            lastName = "Broger";
            email = "brogernh@dukes.jmu.edu";
            major = "CIS";
            phoneNumber = "540 322-7372";
            Username = "brogernh";
            Password = "12345";

            return Page();
        }
        public IActionResult OnPostClearHandler()
        {
            ModelState.Clear();
         
            firstName = "";
            lastName = "";
            email = "";
            phoneNumber = "";
            major = "";
            Username = "";
            Password = "";

            return Page();
        }
    }
}
