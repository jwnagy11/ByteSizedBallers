﻿using GroceryInventory.Pages.DB;
using Microsoft.AspNetCore.Identity;
using OfficeHourInterface.Pages.DataClasses;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace OfficeHourInterface.Pages.DB
{
    public class DBClass
    {
        // Connection at the Class Level
        public static SqlConnection Lab1DBConnection = new SqlConnection();

        // Connection String  
        private static readonly String? officeHourDBConnString = "Server=Localhost;Database=Lab3;Trusted_Connection=True";
        private static readonly String? AuthConnString = "Server=Localhost;Database=AUTH;Trusted_Connection=True";

        //Reads in all the students
        public static SqlDataReader StudentReader()
        {
            SqlCommand studentReader = new SqlCommand();
            studentReader.Connection = Lab1DBConnection;
            studentReader.Connection.ConnectionString = officeHourDBConnString;
            studentReader.CommandText = "SELECT * FROM STUDENT";

            studentReader.Connection.Open();

            SqlDataReader tempReader = studentReader.ExecuteReader();

            return tempReader;
        }

        // Reads in all the instructors
        public static SqlDataReader InstructorReader()
        {
            SqlCommand instructorReader = new SqlCommand();
            instructorReader.Connection = Lab1DBConnection;
            instructorReader.Connection.ConnectionString = officeHourDBConnString;
            instructorReader.CommandText = "SELECT * FROM Instructor";

            instructorReader.Connection.Open();

            SqlDataReader tempReader = instructorReader.ExecuteReader();

            return tempReader;
        }


        // Reads in a single student
        public static SqlDataReader SingleStudentReader(int? studentID)
        {
            SqlCommand studentReader = new SqlCommand();
            studentReader.Connection = Lab1DBConnection;
            studentReader.Connection.ConnectionString = officeHourDBConnString;
            studentReader.CommandText = "SELECT * FROM STUDENT WHERE StudentID = " + studentID;

            studentReader.Connection.Open();

            SqlDataReader tempReader = studentReader.ExecuteReader();

            return tempReader;
        }

        //Reads a single professors office hours
        public static SqlDataReader OfficeHourReader(int instructorId)
        {
            SqlCommand officeHourReader = new SqlCommand();
            officeHourReader.Connection = Lab1DBConnection;
            officeHourReader.Connection.ConnectionString = officeHourDBConnString;
            officeHourReader.CommandText = "SELECT * FROM OfficeHour WHERE OfficeHour.instructorId = " + instructorId;

            officeHourReader.Connection.Open();

            SqlDataReader tempReader = officeHourReader.ExecuteReader();

            return tempReader;
        }

        // reads in a single instructor
        public static SqlDataReader SingleInstructorReader(int i)

        {
            SqlCommand instructorReader = new SqlCommand();
            instructorReader.Connection = new SqlConnection();
            instructorReader.Connection.ConnectionString = officeHourDBConnString;
            instructorReader.CommandText = "SELECT * FROM Instructor WHERE instructorID =" + i;
            instructorReader.Connection.Open();
            SqlDataReader tempReader = instructorReader.ExecuteReader();

            return tempReader;
        }


        public static void UpdateStudent(Student s)
        {
            string sqlQuery = "UPDATE Student SET ";

            sqlQuery += "studentEmail =@StudentEmail,";
            sqlQuery += "studentPhoneNumber =@StudentPhoneNumber,";
            sqlQuery += "major= @Major" 
                + " WHERE studentID= @StudentID";

            SqlCommand cmdProductRead = new SqlCommand();
            cmdProductRead.Connection = new SqlConnection();
            cmdProductRead.Connection.ConnectionString = officeHourDBConnString;
            cmdProductRead.CommandText = sqlQuery;
            cmdProductRead.Parameters.AddWithValue("@StudentEmail", s.studentEmail.ToString());
            cmdProductRead.Parameters.AddWithValue("@StudentPhoneNumber", s.studentPhoneNumber.ToString());
            cmdProductRead.Parameters.AddWithValue("@Major", s.major.ToString());
            cmdProductRead.Parameters.AddWithValue("@StudentID", Int32.Parse(s.studentID.ToString()));
            cmdProductRead.Connection.Open();
            cmdProductRead.ExecuteNonQuery();
        }

        // You might have added this one already . . .check!
        // Can run and return results for any query, if results exist.
        // Query is passed from the invoking code.
        public static SqlDataReader GeneralReaderQuery(string sqlQuery)
        {

            SqlCommand cmdProductRead = new SqlCommand();
            cmdProductRead.Connection = Lab1DBConnection;
            cmdProductRead.Connection.ConnectionString = officeHourDBConnString;
            cmdProductRead.CommandText = sqlQuery;
            cmdProductRead.Connection.Open();
            SqlDataReader tempReader = cmdProductRead.ExecuteReader();

            return tempReader;

        }
        public static SqlDataReader GeneralReaderQuery2(string sqlQuery)
        {

            SqlCommand cmdProductRead = new SqlCommand();
            cmdProductRead.Connection = Lab1DBConnection;
            cmdProductRead.Connection.ConnectionString = AuthConnString;
            cmdProductRead.CommandText = sqlQuery;
            cmdProductRead.Connection.Open();
            SqlDataReader tempReader = cmdProductRead.ExecuteReader();

            return tempReader;

        }

        public static int LoginQuery(string loginQuery)
        {
            // This method expects to receive an SQL SELECT
            // query that uses the COUNT command.

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = Lab1DBConnection;
            cmdLogin.Connection.ConnectionString = officeHourDBConnString;
            cmdLogin.CommandText = loginQuery;
            cmdLogin.Connection.Open();

            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            int rowCount = (int)cmdLogin.ExecuteScalar();

            return rowCount;
        }

        public static int LoginQuery2(string loginQuery)
        {
            // This method expects to receive an SQL SELECT
            // query that uses the COUNT command.

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = Lab1DBConnection;
            cmdLogin.Connection.ConnectionString = AuthConnString;
            cmdLogin.CommandText = loginQuery;
            cmdLogin.Connection.Open();

            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            int rowCount = (int)cmdLogin.ExecuteScalar();

            return rowCount;
        }

        public static void CreateHashedUser(string Username, string Password, int StudentID, string IsInstructor)
        {
            string loginQuery =
                "INSERT INTO HashedCredentials (Username,Password,studentID, isInstructor) " +
                "values (@Username, @Password, @StudentID, @IsInstructor)";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = Lab1DBConnection;
            cmdLogin.Connection.ConnectionString = AuthConnString;

            cmdLogin.CommandText = loginQuery;
            cmdLogin.Parameters.AddWithValue("@Username", Username);
            cmdLogin.Parameters.AddWithValue("@Password", PasswordHash.HashPassword(Password));
            cmdLogin.Parameters.AddWithValue("@StudentID", StudentID);
            cmdLogin.Parameters.AddWithValue("@IsInstructor", IsInstructor);

            cmdLogin.Connection.Open();

            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            cmdLogin.ExecuteNonQuery();

        }

        public static void CreateHashedUserInstructor(string Username, string Password, int InstructorID, string IsInstructor)
        {
            string loginQuery =
                "INSERT INTO HashedCredentials (Username,Password,instructorID, isInstructor) " +
                "values (@Username, @Password, @InstructorID, @IsInstructor)";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = Lab1DBConnection;
            cmdLogin.Connection.ConnectionString = AuthConnString;

            cmdLogin.CommandText = loginQuery;
            cmdLogin.Parameters.AddWithValue("@Username", Username);
            cmdLogin.Parameters.AddWithValue("@Password", PasswordHash.HashPassword(Password));
            cmdLogin.Parameters.AddWithValue("@InstructorID", InstructorID);
            cmdLogin.Parameters.AddWithValue("@IsInstructor", IsInstructor);

            cmdLogin.Connection.Open();

            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            cmdLogin.ExecuteNonQuery();

        }



        public static bool HashedParameterLogin(string Username, string Password)
        {


            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = Lab1DBConnection;
            cmdLogin.Connection.ConnectionString = AuthConnString;

            cmdLogin.CommandType = System.Data.CommandType.StoredProcedure;
            cmdLogin.Parameters.AddWithValue("@Username", Username);
            cmdLogin.CommandText = "sp_Lab3Login";
            cmdLogin.Connection.Open();
            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            SqlDataReader hashReader = cmdLogin.ExecuteReader();
            if (hashReader.Read())
            {
                string correctHash = hashReader["Password"].ToString();

                if (PasswordHash.ValidatePassword(Password, correctHash))
                {
                    return true;
                }
            }

            return false;
        }

    }
}
