using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using OfficeHourInterface.Pages.DataClasses;
using OfficeHourInterface.Pages.DB;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;

namespace OfficeHourInterface.Pages.StudentView
{
    public class ScheduleMeetingModel : PageModel
    {
        [BindProperty]
        public Student curStudent { get; set; }
        [BindProperty]
        public List<SelectListItem> instructorList { get; set; }
        [BindProperty]
        public int instructorID { get; set; }
        [BindProperty]
        [Required]
        public String meetingPurpose { get; set; }
        [BindProperty]
        public int studentID { get; set; }
        [BindProperty]
        public List<SelectListItem> studentList { get; set; }

        public ScheduleMeetingModel()
        {
            studentList = new List<SelectListItem>();
            instructorList = new List<SelectListItem>();
        }

        public IActionResult OnGet(int studentid)
        {
            // Validates that the user is allowed on this page
            if (HttpContext.Session.GetString("username") == null || HttpContext.Session.Get("isInstructor").Equals("No"))
            {
                return RedirectToPage("../Index");
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetInt32("UserID") != studentid && HttpContext.Session.GetString("isInstructor").Equals("No"))
            {
                return RedirectToPage("StudentMeeting", new { studentid = HttpContext.Session.GetInt32("UserID") });
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetString("isInstructor").Equals("Yes"))
            {
                return RedirectToPage("../Index");
            }

            SqlDataReader instructorReader = DBClass.InstructorReader();

            //Gets the instructor information 


            while (instructorReader.Read())
            {
                instructorList.Add(
                    new SelectListItem(
                    instructorReader["instructorFirstName"].ToString() + " " + instructorReader["instructorLastName"].ToString(),
                     instructorReader["instructorID"].ToString()));

            }
            instructorReader.Close();
            DBClass.Lab1DBConnection.Close();

            // Gets the Student information
            SqlDataReader studentReader = DBClass.StudentReader();

            while (studentReader.Read())
            {
                if (!studentReader["studentId"].ToString().Equals(HttpContext.Session.GetInt32("UserID").ToString()))
                {
                    studentList.Add(
                        new SelectListItem(
                       studentReader["studentFirstName"].ToString() + " " + studentReader["studentLastName"].ToString(),
                       studentReader["studentID"].ToString()));
                }


            }
            studentReader.Close();
            DBClass.Lab1DBConnection.Close();

            return Page();

        }

        public IActionResult OnPost()
        {

            return Page();
        }
        // Returns the user back to the student home page
        public IActionResult OnPostCancelHandler()
        {
            return RedirectToPage("StudentInterface", new { studentid = curStudent.studentID });
        }

        // populates text with values
        public IActionResult OnPostPopulateHandler()
        {
            ModelState.Clear();
            meetingPurpose = "Lab 1";
            SqlDataReader instructorReader = DBClass.InstructorReader();

            //Gets the instructor information 


            while (instructorReader.Read())
            {
                instructorList.Add(
                    new SelectListItem(
                    instructorReader["instructorFirstName"].ToString() + " " + instructorReader["instructorLastName"].ToString(),
                     instructorReader["instructorID"].ToString()));

            }
            instructorReader.Close();
            DBClass.Lab1DBConnection.Close();

            // Gets the Student information
            SqlDataReader studentReader = DBClass.StudentReader();

            while (studentReader.Read())
            {
                studentList.Add(
                    new SelectListItem(
                        studentReader["studentFirstName"].ToString() + " " + studentReader["studentLastName"].ToString(),
                        studentReader["studentID"].ToString()));

            }
            studentReader.Close();
            DBClass.Lab1DBConnection.Close();
            return Page();
        }

        // clears the values
        public IActionResult OnPostClearHandler()
        {
            ModelState.Clear();
            meetingPurpose = "";
            SqlDataReader instructorReader = DBClass.InstructorReader();

            //Gets the instructor information 


            while (instructorReader.Read())
            {
                instructorList.Add(
                    new SelectListItem(
                    instructorReader["instructorFirstName"].ToString() + " " + instructorReader["instructorLastName"].ToString(),
                     instructorReader["instructorID"].ToString()));

            }
            instructorReader.Close();
            DBClass.Lab1DBConnection.Close();

            // Gets the Student information
            SqlDataReader studentReader = DBClass.StudentReader();

            while (studentReader.Read())
            {
                studentList.Add(
                    new SelectListItem(
                        studentReader["studentFirstName"].ToString() + " " + studentReader["studentLastName"].ToString(),
                        studentReader["studentID"].ToString()));

            }
            studentReader.Close();
            DBClass.Lab1DBConnection.Close();

            return Page();
        }
    }
}
