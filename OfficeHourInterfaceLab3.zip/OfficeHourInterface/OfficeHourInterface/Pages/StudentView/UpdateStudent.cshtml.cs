using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeHourInterface.Pages.DataClasses;
using OfficeHourInterface.Pages.DB;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Numerics;

namespace OfficeHourInterface.Pages.StudentView
{
    public class UpdateStudentModel : PageModel
    {
        [BindProperty]
        public Student curStudent { get; set; }
        
        public UpdateStudentModel()
        {
            curStudent= new Student();
   
        }
        public IActionResult OnGet(int studentid)
        {
            // validates the current user is allowed on this page

            if (HttpContext.Session.GetString("username") == null || HttpContext.Session.Get("isInstructor").Equals("No"))
            {
                return RedirectToPage("../Index");
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetInt32("UserID") != studentid && HttpContext.Session.GetString("isInstructor").Equals("No"))
            {
                return RedirectToPage("UpdateStudent", new { studentid = HttpContext.Session.GetInt32("UserID") });
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetString("isInstructor").Equals("Yes"))
            {
                return RedirectToPage("../Index");
            }

            // Reads in the student

            SqlDataReader singleStudentReader = DBClass.SingleStudentReader(studentid);

            while (singleStudentReader.Read())
            {
                curStudent.studentID = studentid;
                curStudent.studentFirstName = singleStudentReader["studentFirstName"].ToString();
                curStudent.studentLastName = singleStudentReader["studentLastName"].ToString();
                curStudent.studentEmail = singleStudentReader["studentEmail"].ToString();
                curStudent.studentPhoneNumber = singleStudentReader["studentPhoneNumber"].ToString();
                curStudent.major = singleStudentReader["major"].ToString();
            }

            singleStudentReader.Close();
            DBClass.Lab1DBConnection.Close();
            String date = DateTime.Now.ToString("yyyy_MM-dd");
            return Page();
        }

        // Updates the student information

        public IActionResult OnPost()
        {
            if(ModelState.IsValid)
            {
                DBClass.UpdateStudent(curStudent);
                DBClass.Lab1DBConnection.Close();
                return RedirectToPage("Index", new { studentid = curStudent.studentID });
            } else
            {
                return Page();
            }
           
        }

        // Cancels the request
        public IActionResult OnPostCancel()
        {
            return RedirectToPage("Index", new { studentid = curStudent.studentID });
        }

        // clears textbox
        public void OnPostClear()
        {
            ModelState.Clear();
            curStudent.studentEmail = "";
            curStudent.studentPhoneNumber = "";
            curStudent.major = "";
        }

        // Populates textbox
        public void OnPostPopulate()
        {
            ModelState.Clear();
            int stuID = Int32.Parse(HttpContext.Session.GetInt32("UserID").ToString());
            SqlDataReader singleStudentReader = DBClass.SingleStudentReader(stuID);

            while (singleStudentReader.Read())
            {
                curStudent.studentID = Int32.Parse(singleStudentReader["studentID"].ToString());
                curStudent.studentFirstName = singleStudentReader["studentFirstName"].ToString();
                curStudent.studentLastName = singleStudentReader["studentLastName"].ToString();
                curStudent.studentEmail = singleStudentReader["studentEmail"].ToString();
                curStudent.studentPhoneNumber = singleStudentReader["studentPhoneNumber"].ToString();
                curStudent.major = singleStudentReader["major"].ToString();
            }
            DBClass.Lab1DBConnection.Close();
        }
    }
}
