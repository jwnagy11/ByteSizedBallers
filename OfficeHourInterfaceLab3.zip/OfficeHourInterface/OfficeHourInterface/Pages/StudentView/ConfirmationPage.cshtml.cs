using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeHourInterface.Pages.DB;
using System.Data.SqlClient;

namespace OfficeHourInterface.Pages.StudentView
{
    public class ConfirmationPageModel : PageModel
    {

        [BindProperty]
        public Boolean inQueue { get; set; }
        [BindProperty]
        public int numberInQueue { get; set; }  


        public ConfirmationPageModel() { 
            inQueue= false;
        }
        public IActionResult OnGet(int studentid, int officeHourID)
        {

            // Validates that the user is allowed on this page

            if (HttpContext.Session.GetString("username") == null || HttpContext.Session.Get("isInstructor").Equals("No"))
            {
                return RedirectToPage("../Index");
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetInt32("UserID") != studentid && HttpContext.Session.GetString("isInstructor").Equals("No"))
            {
                return RedirectToPage("OfficeHourInfo", new { studentid = HttpContext.Session.GetInt32("UserID") });
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetString("isInstructor").Equals("Yes"))
            {
                return RedirectToPage("../Index");
            }

            // gets all of the queue informaation for a specific officehour

            string sqlQuery = "SELECT * FROM QUEUE WHERE officeHourId =" + officeHourID;
            SqlDataReader queueReader = DBClass.GeneralReaderQuery(sqlQuery);


            // checks to see if the student is in the queue
            while (queueReader.Read())
            {
                if (Int32.Parse(queueReader["officeHourId"].ToString()) == officeHourID && Int32.Parse(queueReader["studentID"].ToString()) == studentid) {
                    inQueue=true;
                } 
            }
            queueReader.Close();
            DBClass.Lab1DBConnection.Close();


            // selects the locationid for that office hours queue 
            int locationId = 0;
            sqlQuery = "SELECT locationID FROM Queue WHERE officeHourId =" + officeHourID;

            SqlDataReader  locationIDReader = DBClass.GeneralReaderQuery(sqlQuery);

            // stores the locationid
            while (locationIDReader.Read())
            {
                locationId = Int32.Parse(locationIDReader["locationId"].ToString());
            }

            locationIDReader.Close();
            
            // if the student is not in the queue then we add them 
            if (!inQueue)
            {
                DBClass.Lab1DBConnection.Close();
                sqlQuery = "SELECT COUNT(studentId) FROM Queue WHERE officeHourId = " + officeHourID;
                int placeInQueue = DBClass.LoginQuery(sqlQuery);
                placeInQueue = placeInQueue + 1;
        
                DBClass.Lab1DBConnection.Close();

                string watch = "INSERT INTO Queue VALUES (" + officeHourID + "," + studentid + "," + locationId + ", " + placeInQueue + ")";
                DBClass.GeneralReaderQuery("INSERT INTO Queue VALUES (" + officeHourID + "," + studentid + "," + locationId + ", " + placeInQueue + ")");
            }

            DBClass.Lab1DBConnection.Close();

            return Page();
        }
    }
}
