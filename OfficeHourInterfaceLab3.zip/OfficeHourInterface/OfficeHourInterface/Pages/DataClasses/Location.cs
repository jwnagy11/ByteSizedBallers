﻿namespace OfficeHourInterface.Pages.DataClasses
{
    public class Location
    {
        public int locationID { get; set; }
        public int roomNumber { get; set; }
        public String buildingName { get; set; }
    }
}
