﻿namespace OfficeHourInterface.Pages.DataClasses
{
    public class Queue
    {
        public int officeHourID { get; set; }
        public int studentID { get; set; }
        public int locationID { get; set; }
    }
}
