﻿using System.ComponentModel.DataAnnotations;
using System.Numerics;

namespace OfficeHourInterface.Pages.DataClasses
{
    // appropriate info for students
    public class Student
    {
        public int studentID { get; set; }
        public String? studentFirstName { get; set; }
        public String? studentLastName { get; set; }
        [Required]
        public String? studentEmail { get; set; }
        [Required]
        public String? studentPhoneNumber { get; set; }
        [Required]
        public String? major { get; set; }
    }
}


