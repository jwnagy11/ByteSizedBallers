﻿using System.ComponentModel.DataAnnotations;

namespace OfficeHourInterface.Pages.DataClasses
{

    // appropriate info for Instructor
    public class Instructor
    {
        
        public int instructorID { get; set; }
        public String instructorFirstName { get; set; }
        public String instructorLastName { get; set;}
        public String instructorEmail { get; set;}
    }
}
