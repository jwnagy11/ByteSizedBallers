﻿using System.ComponentModel.DataAnnotations;

namespace OfficeHourInterface.Pages.DataClasses
{
    public class Meeting
    {
        public int MeetingID { get; set; }
        [Required]
        public string MeetingDate { get; set; }
        [Required]
        public string MeetingTime { get; set; }
        public int studentId { get; set; }
        public int partnerID { get; set; }
        public int instructorID { get; set; }
        [Required]
        public int locationID { get; set; }
    }
}
