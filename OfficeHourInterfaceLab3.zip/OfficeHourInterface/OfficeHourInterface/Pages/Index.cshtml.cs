﻿using GroceryInventory.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeHourInterface.Pages.DataClasses;
using OfficeHourInterface.Pages.DB;
using System.Data.SqlClient;
using System.Numerics;

namespace OfficeHourInterface.Pages
{
    public class IndexModel : PageModel
    {

        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }
        [BindProperty]
        public string Username { get; set; }
        [BindProperty]
        public string Password { get; set; }
        [BindProperty]
        public string hash { get; set; }


        public IActionResult OnGet(String logout)
        {

            if (logout != null)
            {

                HttpContext.Session.Clear();
                ViewData["LoginMessage"] = "Logged out Successfully!";
            }
            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetString("isInstructor").Contains("Yes"))
            {
                return RedirectToPage("/InstructorView/Index");
            }

            if (HttpContext.Session.GetString("username") != null && HttpContext.Session.GetString("isInstructor").Contains("No"))
            {
                return RedirectToPage("/StudentView/Index");
            }

            DBClass.Lab1DBConnection.Close();


      

            return Page();
        }

        public IActionResult OnPost()
        {

            //if (Username != null && Password != null && DBClass.HashedParameterLogin(Username, Password))
            //{
            //    HttpContext.Session.SetString("username", Username);
            //    ViewData["LoginMessage"] = "Login Successful!";
            //    DBClass.GroceryDBConnection.Close();
            //    return Page();
            //}


            if (Username != null && Password != null && DBClass.HashedParameterLogin(Username, Password))
            {
                DBClass.Lab1DBConnection.Close();

                string sqlQuery = "SELECT studentID, instructorId, isInstructor FROM HashedCredentials where Username = '";
                sqlQuery += Username + "'";
                HttpContext.Session.SetString("username", Username);

             
                SqlDataReader userReader = DBClass.GeneralReaderQuery2(sqlQuery);

                

                while (userReader.Read())
                {
                    if (!userReader["studentId"].ToString().Equals(""))
                    {
                        HttpContext.Session.SetInt32("UserID", Int32.Parse(userReader["studentID"].ToString()));
                        HttpContext.Session.SetString("isInstructor", userReader["isInstructor"].ToString());
                        userReader.Close();
                        DBClass.Lab1DBConnection.Close();
                        return RedirectToPage("StudentView/Index", new { studentid = HttpContext.Session.GetInt32("UserID") });
                    }
                    if (!userReader["instructorId"].ToString().Equals(""))
                    {
                        HttpContext.Session.SetInt32("UserID", Int32.Parse(userReader["instructorID"].ToString()));
                        HttpContext.Session.SetString("isInstructor", userReader["isInstructor"].ToString());
                        userReader.Close();
                        DBClass.Lab1DBConnection.Close();
                        return RedirectToPage("InstructorView/Index", new { instructorid = HttpContext.Session.GetInt32("UserID") });
                    }
                   

                }
  
            }
            else
            {
                ViewData["LoginMessage"] = "Username and/or Password Incorrect";

            }
            DBClass.Lab1DBConnection.Close();
            return Page();

        }
        
        public void OnPostStudent()
        {
            ModelState.Clear();
            
            Username = TempData.Peek("sUsername").ToString();
            Password = TempData.Peek("sPassword").ToString();
        }
        public void OnPostInstructor()
        {
            ModelState.Clear();
            Username = TempData.Peek("iUsername").ToString();
            Password = TempData.Peek("iPassword").ToString();
        }

        public void OnPostClear()
        {
            ModelState.Clear();
            Username = "";
            Password = "";
        }

    }
}